/* Aluno Guilherme Silva de Lima turma: 1A de LOP
resolução da prova2
Jogo : As direções para o objetivo
videos de explicação em baixo*/

//https://youtu.be/wJekCfI8_kQ
//https://youtu.be/4L4_-I4ktiA

var largura = 200;
var altura = 45;
var xMenu = 170;
var yMenu1 = 154;
var yMenu2 = 214;
var yMenu3 = 274;
var xImagem = 250;
var yImagem = 200;
var rua1 = 2;
var rua2 = 516;
var rua3 = 426;
var telas = menu;
//var objetivo =1;
let img;
function preload(){
  img = loadImage('bairro.jpg');
  img2 = loadImage('eueumesmo.jpg');
  img3 = loadImage('amiga de mãe.jpg');
  img4 = loadImage('boneco.png');
  img5 = loadImage('balão.jpg');
}

function setup() {
  createCanvas(520, 520);
}

function draw() {
  textStyle(NORMAL);
  telas();
} 

//--MENU--

  function menu(){

    background(0,220,0);
    image(img,0,0,520,520);
    
    textAlign(CENTER);
    textSize(30);
 
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu1 && mouseY < yMenu1 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,yMenu1, largura, altura, 15);
       if(mouseIsPressed){
      telas = jogar;
      }
    }
    fill(240);
    noStroke();
    text("JOGAR",270, 187 );
    
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu2 && mouseY < yMenu2 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,yMenu2, largura, altura, 15);
       if(mouseIsPressed){
      telas = telainst;
      }
    }
    fill(240);
    noStroke();
    text("INTRUÇÕES",270, 247 );
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu3 && mouseY < yMenu3 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,yMenu3, largura, altura, 15);
      if(mouseIsPressed){
      telas = telacre;
      }
    }
    fill(240);
    noStroke();
    text("CRÉDITOS",270, 307 );
  }

//--TELA DE INSTRUÇÕES--

function telainst(){
  background(150);
  textSize(30);
  text("INSTRUÇÕES",255,35);
  textSize(20);
  text("Esse jogo foi desenvolvido para ajudar alunos do 1°ano,",254, 75 );
  text("com objetivo da BNCC (MATEMÁTICA(EF01MA11)) em  ",259,100);
  text("descrever a localização de pessoas e de objetos no",235,125);
  text("espaço em relação a sua propria posição, ultilizando",239,150);
  text("termos como (á direita, á esquerda, em frente e atrás).",250,175);
  text("O objetivo do jogo é completar missões de deslocamento,",260,225);
  text("que consistem em alcançar algum dos elementos de",239,250);
  text("cenario.",43,275);
  
   if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > 452 && mouseY < 452 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,460, largura, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("VOLTAR",271, 490 );
} 

//--TELA DE CRÉDITOS--

function telacre(){
  
  background(20);
  textSize(32);
  text("CRÉDITOS",250, 40 );
  textSize(20);
  text("Guilherme Silva de LIMA :",280,130);
  text("Programador",226,160);
  text("Maria Ludmila Massal de Sales :",308,320);
  text("Educadora",212,350);
  image(img2,10,85,145,145);
  image(img3,10,275,145,145);
  
  
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > 452 && mouseY < 452 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,460, largura, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("VOLTAR",271, 490 );
  
}

//--JOGO--

function jogar(){
  image(img,0,60,520,380);
   fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 1",424, 460);
  textSize(35);
  text("Missão: "+"Vá até o balão",190,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img5,265,80,25,60);
  image(img4,xImagem,yImagem);
  if((xImagem>=255 && xImagem<=255+30)&&(yImagem>=70 && yImagem<= 70+30)){
    tela == fase2;
     }
  
}
function fase2(){
  
   image(img,0,60,520,380);
   fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: ",424, 460);
  textSize(35);
  text("Missão: "+"A fazer",190,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img5,265,80,25,60);
}