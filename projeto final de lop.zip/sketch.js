/*Projeto de Guilherme Silva de Lima
Jogo: as direções para o objetivo
link da explicação: */
var largura = 200;
var altura = 45;
var xMenu = 170;
var yMenu1 = 154;
var yMenu2 = 214;
var yMenu3 = 274;
var xImagem = 250;
var yImagem = 200;
var rua1 = 2;
var rua2 = 516;
var rua3 = 426;
var xCarro = 80;
var xMovimento = 410;
var yMovimento = 200;
var telas = menu;
let img;
function preload(){
  img = loadImage('bairro.jpg');
  img2 = loadImage('eueumesmo.jpg');
  img3 = loadImage('amiga de mãe.jpg');
  img4 = loadImage('boneco.png');
  img5 = loadImage('balão.jpg');
  img6 = loadImage('carro.png');
  img7 = loadImage('pessoa.png');
  img8 = loadImage('caminhão_azul.png');
  img9 = loadImage('carro_vermelho.png');
  img10 = loadImage('caminhão_vermelho.png');
  img11 = loadImage('FIM.png');
}

function setup() {
  createCanvas(520, 520);
}

function draw() {
  textStyle(NORMAL);
  telas();
} 

//--MENU--

  function menu(){

    background(0,220,0);
    image(img,0,0,520,520);
    
    textAlign(CENTER);
    textSize(30);
 
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu1 && mouseY < yMenu1 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,yMenu1, largura, altura, 15);
       if(mouseIsPressed){
      telas = jogar;
      }
    }
    fill(240);
    noStroke();
    text("JOGAR",270, 187 );
    
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu2 && mouseY < yMenu2 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,yMenu2, largura, altura, 15);
       if(mouseIsPressed){
      telas = telainst;
      }
    }
    fill(240);
    noStroke();
    text("INTRUÇÕES",270, 247 );
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > yMenu3 && mouseY < yMenu3 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,yMenu3, largura, altura, 15);
      if(mouseIsPressed){
      telas = telacre;
      }
    }
    fill(240);
    noStroke();
    text("CRÉDITOS",270, 307 );
  }

//--TELA DE INSTRUÇÕES--

function telainst(){
  background(150);
  textSize(30);
  text("INSTRUÇÕES",255,35);
  textSize(20);
  text("Esse jogo foi desenvolvido para ajudar alunos do 1°ano,",254, 75 );
  text("com objetivo da BNCC (MATEMÁTICA(EF01MA11)) em  ",259,100);
  text("descrever a localização de pessoas e de objetos no",235,125);
  text("espaço em relação a sua propria posição, ultilizando",239,150);
  text("termos como (á direita, á esquerda, em frente e atrás).",250,175);
  text("O objetivo do jogo é completar missões de deslocamento,",260,225);
  text("que consistem em alcançar algum dos elementos de",239,250);
  text("cenario.",43,275);
  
   if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > 452 && mouseY < 452 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,460, largura, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("VOLTAR",271, 490 );
} 

//--TELA DE CRÉDITOS--

function telacre(){
  
  background(20);
  textSize(32);
  text("CRÉDITOS",250, 40 );
  textSize(20);
  text("Guilherme Silva de LIMA :",280,130);
  text("Programador",226,160);
  text("Maria Ludmila Massal de Sales :",308,320);
  text("Educadora",212,350);
  image(img2,10,85,145,145);
  image(img3,10,275,145,145);
  
  
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > 452 && mouseY < 452 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,460, largura, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("VOLTAR",271, 490 );
  
}

//--JOGO--

function jogar(){
  image(img,0,60,520,380);
   fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 1",424, 460);
  textSize(35);
  text("Missão: "+"Vá até o balão",190,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img5,265,80,25,60);
  image(img4,xImagem,yImagem);
  if(dist(265,80,xImagem,yImagem)<25){
    telas = fase2;
     }
  
}

//--FASE 2--
function fase2(){
  
   image(img,0,60,520,380);
   fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 2",424, 460);
  textSize(35);
  text("Missão: "+"Chegue até o carro",227,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img6,80,290,60,60);
  image(img4,xImagem,yImagem);
  if(dist(80,290,xImagem,yImagem)<40){
    telas = fase3;
     }
}

//--FASE 3--

function fase3(){
  
   image(img,0,60,520,380);
   fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 3",424, 460);
  textSize(35);
  text("Missão: "+"Vá até o homem",227,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img7,410,200,45,45);
  image(img4,xImagem,yImagem);
  if(dist(410,200,xImagem,yImagem)<30){
    telas = fase4;
}
}

//--FASE 4--
  
function fase4(){
  
  image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 4",424, 460);
  textSize(35);
  text("Missão: "+"Vá até o balão de baixo",252,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  

  image(img5,265,80,25,60);
  image(img5,425,368,25,60);
  image(img4,xImagem,yImagem);
  if(dist(425,368,xImagem,yImagem)<35){
    telas = fase5;
}
  
  }

//--FASE 5--

function fase5(){

image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 5",424, 460);
  textSize(35);
  text("Missão: "+"Chegue até o carro",220,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img6,xCarro,290,60,60);
  if(xCarro<439){
    xCarro=xCarro+3;
     }
  image(img4,xImagem,yImagem);
  if(dist(xCarro,290,xImagem,yImagem)<25){
    telas = fase6;
}
}

//--FASE 6--

function fase6(){

image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 6",424, 460);
  textSize(35);
  text("Missão: "+"Chegue até o homem",252,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  

  image(img7,xMovimento,yMovimento,45,45);
  if(yMovimento>122&&xMovimento==410){
    yMovimento--;
     }
  if(yMovimento<130&&xMovimento>258){
    xMovimento--;
     }
  if(xMovimento<=260&&yMovimento<290){
    yMovimento++;
     }
  if(yMovimento==290&&xMovimento<410){
     xMovimento++;
     }
  
  image(img4,xImagem,yImagem);
  if(dist(xMovimento,yMovimento,xImagem,yImagem)<25){
    telas = fase7;
}

}

//--FASE 7--

function fase7(){

  
   image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 7",424, 460);
  textSize(35);
  text("Missão: "+"Qual não é o balão",252,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  

  image(img5,265,80,25,60);
  image(img5,425,368,25,60);
  image(img5,425,80,25,60);
  image(img7,260,368,45,45);
  
  image(img4,xImagem,yImagem);
  if(dist(260,368,xImagem,yImagem)<25){
    telas = fase8;
}
  
}

//--FASE 8--

function fase8(){

  image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 8",424, 460);
  textSize(35);
  text("Missão: "+"Vá até carro de cima",252,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img6,80,120,60,60);
  image(img6,xCarro,290,60,60);
  if(xCarro<439){
    xCarro=xCarro+3;
     }
  image(img4,xImagem,yImagem);
  if(dist(80,120,xImagem,yImagem)<25){
    telas = fase9;
}  
}

//--FASE 9--

function fase9(){

  image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 9",424, 460);
  textSize(35);
  text("Missão: "+"Vá até caminhão azul",252,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img6,100,125,60,60);
  image(img7,9,298,40,40);
  image(img8,425,142,90,30);
  image(img9,20,133,70,50);
  image(img9,170,133,70,50);
  image(img10,448,308,70,30);
  image(img10,100,308,70,30);
  image(img4,xImagem,yImagem);
  if(dist(425,142,xImagem,yImagem)<50){
    telas = fase10;
}
}

//--FASE 10--

function fase10(){
  image(img,0,60,520,380);
  fill(0,220,0);
  rect(rua1,rua1,516,62);
  rect(rua1,430,rua2,520);
  fill(05);
  rect(rua1, 128, rua2, 40,);
  rect(rua1, 295, rua2, 40);
  rect(265,63,32,370);
  rect(420,63,32,370);
  textSize(20);
  text("NÍVEL: 10",424, 460);
  textSize(35);
  text("Missão: "+"Alcance o homem",252,40);
  
//BOTÃO ESQUERDO
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,430, 130, altura, 15);
      if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("ESQUERDA",70, 460 );
  
//BOTÃO FRENTE
  
  if(mouseX > 7 && mouseX < 7 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(7,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem-- ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("FRENTE",70, 500 );


//BOTÃO DIREITA
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 419 && mouseY < 419 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,430, 130, altura, 15);
        if(mouseIsPressed){
         if((yImagem>100 && yImagem<120) || ( yImagem>265 && yImagem<290)){
          xImagem++ ;
         }
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("DIREITA",245, 460 );
  
//BOTÃO TRÁS
  
  if(mouseX > 180 && mouseX < 180 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(180,471, 130, altura, 15);
       if(mouseIsPressed){
         if((xImagem>240 && xImagem<272) || ( xImagem>395 && xImagem<422)){
          yImagem++ ;
         }
       }
   }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("TRÁS",245, 500 );

//BOTÃO DE SAIR
  
  if(mouseX > 361 && mouseX < 361 + 130 && mouseY > 477 && mouseY < 477 + altura){
      stroke(200);
      fill(66,33,33);
      rect(361,471, 130, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("SAIR",425, 500 );
  
//PERSONAGEM
  
  image(img7,xMovimento,yMovimento,40,40);
  if(yMovimento<395&&xMovimento<500&&xMovimento>400){
     yMovimento++;
     }
  if(yMovimento==395&&xMovimento>300){
     xMovimento=0;
     yMovimento=297;
     }
  if(yMovimento==297&&xMovimento<260){
     xMovimento++;
     }
  if(yMovimento<395&&xMovimento<266&&xMovimento>250){
     yMovimento++;
     }
  if(yMovimento==394&&xMovimento<300&&yMovimento>340){
     xMovimento=410;
     yMovimento=60;
     }
  image(img4,xImagem,yImagem);
  if(dist(xMovimento,yMovimento,xImagem,yImagem)<25){
    telas = fim;
}
}

//--FIM--

function fim(){

  background(20);
  image(img11,0,0,520,520);
  textSize(50);
  text("OBRIGADO",260,100);
  text("POR",260,200);
  text("JOGAR",260,300);
  
    if(mouseX > xMenu && mouseX < xMenu + largura && mouseY > 350 && mouseY < 350 + altura){
      stroke(200);
      fill(66,33,33);
      rect(xMenu,350, largura, altura, 15);
       if(mouseIsPressed){
         telas = menu;
       }
    }
  fill(240);
    noStroke();
   textAlign(CENTER);
    textSize(20)
    text("MENU",271, 380 );
  
}